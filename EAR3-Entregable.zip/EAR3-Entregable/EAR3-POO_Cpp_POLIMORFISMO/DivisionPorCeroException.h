/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#ifndef DIVISIONPORCEROEXCEPTION_H_INCLUDED
#define DIVISIONPORCEROEXCEPTION_H_INCLUDED

#include <exception>

using namespace std;

class DivisionPorCeroException : public exception
{


/// complete la declaraci�n de la class


#endif // DIVISIONPORCEROEXCEPTION_H_INCLUDED

