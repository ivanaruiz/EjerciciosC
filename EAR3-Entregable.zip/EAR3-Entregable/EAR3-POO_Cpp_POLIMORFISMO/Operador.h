/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#ifndef OPERADOR_H_INCLUDED
#define OPERADOR_H_INCLUDED

#include <string>

using namespace std;

class Operador
{
private:
    float _operA;
    float _operB;


/// complete la declaraci�n de la class


#endif // OPERADOR_H_INCLUDED

