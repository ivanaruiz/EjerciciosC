/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#include "Resta.h"

Resta:: . . .



/// complete la definici�n de la class


