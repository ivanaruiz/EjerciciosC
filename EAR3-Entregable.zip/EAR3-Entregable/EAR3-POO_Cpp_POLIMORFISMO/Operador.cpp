/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#include "Operador.h"

Operador:: . . .



/// complete la definici�n de la class


