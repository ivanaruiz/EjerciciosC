/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#ifndef RESTA_H_INCLUDED
#define RESTA_H_INCLUDED

#include "Operador.h"

class Resta : public Operador
{
public:



/// complete la declaraci�n de la class


#endif // RESTA_H_INCLUDED

