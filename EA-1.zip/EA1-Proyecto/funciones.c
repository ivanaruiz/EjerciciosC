
#include "funciones.h"





/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//* FUNCIONES A DESARROLLAR                                            *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**
int contarOcurrencias1_MIO(const char *cad, const char *sub)
{

}

int contarOcurrencias2_MIO(const char *cad, const char *sub)
{

}

void rotarMat_MIO(int m[][COLUM], int filas, int colum)
{

}

int  mostrarMatTriangDerInf_MIO(int m[][COLUM], int filas, int colum)
{

}



int  ordenarArchivo_MIO(const char *archEnt, const char *archSal)
{

}


void crearPila_MIO(tPila *p)
{

}


int  pilaLlena_MIO(const tPila *p, unsigned cantBytes)
{

}


int  ponerEnPila_MIO(tPila *p, const void *d, unsigned cantBytes)
{

}


int  verTope_MIO(const tPila *p, void *d, unsigned cantBytes)
{

}


int  pilaVacia_MIO(const tPila *p)
{

}


int  sacarDePila_MIO(tPila *p, void *d, unsigned cantBytes)
{

}


void vaciarPila_MIO(tPila *p)
{

}


 */
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
