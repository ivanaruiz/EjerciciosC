/**//* 33.329.371-RUIZ,IvanaAnahiVictoria-(06-2965) *//**/


/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO AC�   *//**//**/

/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO AC�   *//**//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#include "funciones.h"
#include <string.h>
#include <stdlib.h>

void reacomodarElPrimero(tNodo * inicio, tNodo * mayor);
tNodo * reacomodarLosSiguientes(tNodo * auxAnt, tNodo * auxSig, tNodo * mayor,
             int (*comparar)(const void *, const void *));
tNodo * buscarMayor(tNodo * inicio, int (*comparar)(const void *, const void *), int * max);
tNodo * irInicio(tLista *p);
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� DEBE DESARROLLAR LAS FUNCIONES Y PRIMITIVAS PEDIDAS    *//**//**/
/**//**//* ADEM�S DE CUALQUIER OTRA FUNCI�N QUE SE REQUIERA           *//**//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//* FUNCIONES Y PRIMITIVAS A DESARROLLAR                               *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//* para la informaci�n                                                *//**/

void mostrarFinal_MIO(const void *d, FILE *fp)
{
    if(!d)
        return;

    const tFinal * alum = (const tFinal*) d;
    fprintf(fp, "%s %-30s %d %2d\n", alum->dni, alum->apYNom, alum->codMat, alum->calif);
}

int  compararFinal_MIO(const void *d1, const void *d2)
{
    const tFinal * alum1 = (const tFinal *) d1;
    const tFinal * alum2 = (const tFinal *) d2;

    return strcmpi(alum1->dni, alum2->dni);
}


int  acumularCalif_MIO(void **dest, unsigned *tamDest,
                       const void *orig, unsigned tamOrig)
{
    if(*dest == NULL || orig== NULL)
        return 0;

    tFinal * acum = (tFinal *) *dest;
    const tFinal * alum = (const tFinal *) orig;

    acum->calif += alum->calif;
    return 1;
}


void mostrarProm_MIO(const void *d2, int cantCalif, FILE *fp)
{
    const tFinal * prom = (const tFinal *) d2;

    fprintf(fp,"   --- Rindio  %d final(es) con un promedio de: %2.0f\n\n",
            cantCalif, (float)prom->calif/cantCalif);
}


/**//* para el TDA LISTA                                                  *//**/

int  mostrarDeIzqADer_MIO(const tLista *p,
                          void(*mostrar)(const void *, FILE *), FILE *fp)
{
    int contNodos = 0;

    if(!*p)
        return 0;           //lista vac�a

    while((*p)->ant)        //voy al principio de la lista
        p = &(*p)->ant;

    fprintf(fp, " D. N. I.  Apellido(s), Nombre(s)         CodM Cal\n");
    while(*p)               //recorro la lista, muestro y cuento
    {
        contNodos++;
        mostrar((*p)->info, fp);
        p = &(*p)->sig;
    }
    return contNodos;
}


void ordenarLista_MIO(tLista *p, int (*comparar)(const void *, const void *))
{
    if(!*p)
        return;

    tNodo   * mayor;
    tNodo   * inicio = irInicio(p);
    tNodo   * auxSig,
            * auxAnt;

    int primeraVez=0;   //esta variable la uso solo para el primer mayor encontrado

    while(inicio)
    {
        int cont=0;
        primeraVez++;

        mayor = buscarMayor(inicio, comparar, &cont);

        if(cont<=1)     //cuando ya no hay nodos que se repitan, simplemente salgo
            return;

        if(primeraVez==1)       //entro cuando se trata del primer nodo que ordenar�
        {
            if(mayor!=inicio)   //cuando mi primer mayor es el primer nodo de la lista,
            {                   //no hace falta reordenarlo, como en nuestro ejemplo
                reacomodarElPrimero(inicio, mayor);
            }
            auxAnt = mayor;
            auxSig = auxAnt->sig;
        }
        else    //para todos los siguientes nodos que voy a reacomodar
            {auxSig= inicio;
            auxAnt = auxSig->ant;}

        inicio = reacomodarLosSiguientes(auxAnt, auxSig, mayor, comparar);
    }
}
//con esta funci�n, acomodo el primer nodo al principio de la lista
void reacomodarElPrimero(tNodo * inicio, tNodo * mayor)
{
    mayor->sig->ant = mayor->ant;
    mayor->ant->sig = mayor->sig;

    mayor->sig = inicio;
    mayor->ant = NULL;

    inicio->ant = mayor;
}

tNodo * reacomodarLosSiguientes(tNodo * auxAnt, tNodo * auxSig, tNodo * mayor,
             int (*comparar)(const void *, const void *))
{
    tNodo * aux = auxSig;

    while(aux)
    {   //cuando encuentre los nodos correspondientes, har� los desenganches y enganches
        if((comparar(mayor->info , aux->info )==0 && auxSig!=aux))
        {
            if(aux->sig)
                {aux->ant->sig = aux->sig;
                aux->sig->ant = aux->ant;}
            else
                aux->ant->sig = NULL;

            aux->sig = auxSig;
            aux->ant = auxAnt;

            auxSig->ant = aux;
            auxAnt->sig = aux;

            auxAnt= auxAnt->sig;
        }
        else if(comparar(mayor->info , aux->info )==0  && aux->sig)
            {auxSig = auxSig->sig;
            auxAnt = auxAnt->sig;}

        aux = aux->sig; //finalmente avanzo para seguir buscando los otros nodos
    }
    return auxSig;
}

//con mayor nos referimos al que tiene mas ocurrencias
tNodo * buscarMayor(tNodo * inicio, int (*comparar)(const void *, const void *), int * max)
{
    tNodo * maxNodo = inicio;
    tNodo * aux = inicio;

    while((inicio)->sig)
    {
        int cont=0;
        while(aux)
        {
            if(comparar( (inicio)->info, (aux)->info)==0)
                cont++;

            aux= aux->sig;
        }
        if(cont>*max)
            {*max=cont;
            maxNodo = inicio;}  //ac� encontramos al de mayor ocurrencia (por ahora)

        inicio= (inicio)->sig;
        aux = inicio;
    }
    return maxNodo;
}

tNodo * irInicio(tLista *p)
{
    while((*p)->ant)
            p = &(*p)->ant;
    tNodo * aux= *p;
    return aux;
}

int  vaciarMostrarDetalleYProm_MIO(tLista *p, FILE *fp,
                                   int (*comparar)(const void *, const void *),
                                   int (*acumular)(void **, unsigned *,
                                                   const void *, unsigned),
                                   void (*mostrar)(const void *, FILE *),
                                   void (*mostrar2)(const void *, int, FILE *))
{
    if(!*p)
        return 0;
    tNodo * act = *p;
    int contFinalesXAlumno=0;
    int contNodos = 0;

    if(act)
    {
        while(act->ant)
            act = act->ant;

        while(act)
        {
            contFinalesXAlumno=0;
            contNodos++;
            fprintf(fp, " D. N. I.  Apellido(s), Nombre(s)         CodM Cal\n");
            mostrarFinal_MIO(act->info, fp);

                while(act->sig && compararFinal_MIO(act->info, act->sig->info)==0)
                {
                tNodo *aux = act->sig;

                mostrarFinal_MIO(act->sig->info, fp);
                acumularCalif_MIO(&(act)->sig->info, &(act)->tamInfo, (act)->info, sizeof(tFinal));

                free(act->info);
                free(act);
                act = aux;
                contNodos++;
                contFinalesXAlumno++;
                }

                mostrarProm_MIO((act)->info, contFinalesXAlumno+1, fp);
                act = (act)->sig;
        }
        *p = NULL;
    }
    return contNodos;
}
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

