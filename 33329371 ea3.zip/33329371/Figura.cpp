/**//* 33.329.371-RUIZ,IvanaAnahiVictoria-(06-2965) *//**/

#include "Figura.h"

//destructor
Figura::~Figura()
{
}

